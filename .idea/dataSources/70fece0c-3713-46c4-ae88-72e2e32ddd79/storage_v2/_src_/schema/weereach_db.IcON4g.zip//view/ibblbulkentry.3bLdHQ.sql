CREATE VIEW ibblbulkentry AS
  SELECT
    `weereach_db`.`sms_entries`.`id`            AS `Id`,
    `weereach_db`.`sms_entries`.`user_id`       AS `UserId`,
    `weereach_db`.`sms_entries`.`campaign_name` AS `Campaign`,
    `weereach_db`.`sms_entries`.`type`          AS `SmsType`,
    `weereach_db`.`sms_entries`.`length`        AS `BodyLength`,
    `weereach_db`.`sms_entries`.`count`         AS `SmsCount`,
    `weereach_db`.`sms_entries`.`mask`          AS `SenderMask`,
    `weereach_db`.`sms_entries`.`recipient`     AS `Recipient`,
    `weereach_db`.`sms_entries`.`body`          AS `SmsBody`,
    `weereach_db`.`sms_entries`.`status`        AS `SendingStatus`,
    `weereach_db`.`sms_entries`.`scheduled_at`  AS `InsertedAt`,
    `weereach_db`.`sms_entries`.`created_at`    AS `ScheduleTime`,
    `weereach_db`.`sms_entries`.`updated_at`    AS `ProcessedAt`,
    `weereach_db`.`sms_entries`.`sent_at`       AS `SentAt`,
    `weereach_db`.`sms_entries`.`delivered_at`  AS `DeliveredAt`,
    `weereach_db`.`sms_entries`.`remarks`       AS `Remarks`
  FROM `weereach_db`.`sms_entries`
  WHERE (`weereach_db`.`sms_entries`.`user_id` = 6);

