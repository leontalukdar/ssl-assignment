CREATE TRIGGER sms_entries_before
  BEFORE INSERT
  ON sms_entries
  FOR EACH ROW
  BEGIN
    IF NEW.is_direct_insert=1 THEN
        SET NEW.priority = 1;
        IF NEW.user_id NOT IN (6) THEN
            SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'not allowed to insert';  
        END IF;
       
        IF NEW.user_id=6 AND NEW.mask <> 'IslamiBank' THEN
           SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'not allowed to insert';  
        END IF;       
         
        IF NEW.mask='IslamiBank' THEN
        	SET @num = RIGHT(NEW.recipient, 11);
            IF LEFT(@num, 3)='016' OR LEFT(@num, 3)='018' THEN
                SET NEW.gateway_uid = "01611111111";
            END IF;            
            IF LEFT(@num, 3)='017' THEN
                SET NEW.gateway_uid = "01711111111";
            END IF;
        END IF;
                 
    END IF;
    
    SET NEW.uuid = uuid();
    IF NEW.parent_id IS NULL THEN 
     SET NEW.parent_id = NEW.user_id;
    END IF;
END;

