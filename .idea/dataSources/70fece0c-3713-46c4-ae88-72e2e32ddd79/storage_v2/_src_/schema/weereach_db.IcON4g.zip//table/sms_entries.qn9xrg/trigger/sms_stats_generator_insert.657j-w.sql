CREATE TRIGGER sms_stats_generator_insert
  AFTER INSERT
  ON sms_entries
  FOR EACH ROW
  BEGIN
	IF NOT EXISTS(SELECT * FROM sms_stats WHERE date=DATE(NEW.scheduled_at) AND `user_id`=NEW.user_id AND `parent_id`=NEW.parent_id)  THEN
        INSERT INTO `sms_stats`(`user_id`, `parent_id`, `date`, `total_submitted`, `failed`, `total_sent`, `total_sent_count`, `mask_sent`, `mask_sent_count`, `fallback_sent`, `fallback_sent_count`) VALUES (NEW.user_id, NEW.parent_id, DATE(NEW.scheduled_at), 0, 0, 0, 0, 0, 0, 0, 0);
    END IF;
    

    SELECT `id`, `total_submitted`  FROM sms_stats WHERE `date`=DATE(NEW.scheduled_at) AND  `user_id`=NEW.user_id AND `parent_id`=NEW.parent_id INTO @id, @total_submitted;
    UPDATE sms_stats SET `total_submitted`= @total_submitted+1 WHERE `id`=@id ;
END;

