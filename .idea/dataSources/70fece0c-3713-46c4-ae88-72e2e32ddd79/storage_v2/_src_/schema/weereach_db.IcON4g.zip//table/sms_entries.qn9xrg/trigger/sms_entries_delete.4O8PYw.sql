CREATE TRIGGER sms_entries_delete
  BEFORE DELETE
  ON sms_entries
  FOR EACH ROW
  BEGIN
    IF OLD.status='SENT' THEN
         SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'can\'t delete sent entry.';
    END IF;
END;

