CREATE TRIGGER sms_entries_before
  BEFORE INSERT
  ON sms_entries
  FOR EACH ROW
  BEGIN
    
    SET @gsm_chars = "^[]@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà{}\[~|€^-]+$";
    SET @extended_gsm_chars = "[]{}\[~|€^]";
    SET @len = char_length(NEW.body);  

      IF NEW.body REGEXP @gsm_chars THEN
        IF NEW.type IN (1, 2) THEN
          SET NEW.type = NEW.type;
        ELSE
          SET NEW.type =  1;
        END IF;
    
        IF New.body REGEXP @extended_gsm_chars THEN
          SET NEW.count = ceil(@len/140);
        ELSE
          SET @len = 2*@len-length(replace(NEW.body, "\n", ""));
          IF @len<=160 THEN
            SET NEW.count = 1;
          ELSE
            SET NEW.count = ceil(@len/153);
          END IF;
        END IF ;
      ELSE
        SET NEW.type = 3;
        IF @len <= 70 THEN
          SET NEW.count = 1;
        ELSE
          SET NEW.count = ceil(@len/67);
        END IF;
      END IF ;
      
      SET NEW.length = @len;
END;

