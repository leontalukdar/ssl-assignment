CREATE TRIGGER sms_stats_generator_update
  BEFORE UPDATE
  ON sms_entries
  FOR EACH ROW
  BEGIN

    SELECT `id`, `total_submitted`, `failed`, `total_sent`, `total_sent_count`, `mask_sent`, `mask_sent_count`, 
    `fallback_sent`, `fallback_sent_count`  FROM sms_stats 
    WHERE `date`=DATE(OLD.scheduled_at) AND `user_id`=OLD.user_id LIMIT 1
        INTO @id, @total_submitted, @failed, @total_sent, @total_sent_count, @mask_sent, @mask_sent_count, @fallback_sent, @fallback_sent_count FOR UPDATE;

    
    IF NEW.status<>OLD.status THEN
    
        IF NEW.status='SENT' THEN
            UPDATE sms_stats SET `total_sent`=@total_sent+1, `total_sent_count`=@total_sent_count+NEW.count WHERE `id`=@id;

            IF NEW.mask<>'NOMASK' THEN
                UPDATE sms_stats SET `mask_sent`=@mask_sent+1, `mask_sent_count`=@mask_sent_count+NEW.count WHERE `id`=@id;
            END IF;
            IF NEW.is_non_mask_sent=1 THEN
                UPDATE sms_stats SET `fallback_sent`=@fallback_sent+1, `fallback_sent_count`=@fallback_sent_count+NEW.count WHERE `id`=@id;
            END IF;
        ELSEIF OLD.status='SENT' THEN
            SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'sent sms status can\'t be changed.';
        END IF;
        
        IF NEW.status='FAILED' AND OLD.status<>'FAILED' THEN
             UPDATE sms_stats SET `failed`=@failed+1 WHERE `id`=@id;
        END IF;
        
        IF OLD.status='FAILED' AND NEW.status<>'FAILED' THEN
            UPDATE sms_stats SET `failed`=@failed-1 WHERE `id`=@id;
        END IF;
    END IF;
END;

