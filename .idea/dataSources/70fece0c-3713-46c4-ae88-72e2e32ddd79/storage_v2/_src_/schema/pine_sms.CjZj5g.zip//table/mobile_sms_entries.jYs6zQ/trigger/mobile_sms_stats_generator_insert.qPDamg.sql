CREATE TRIGGER mobile_sms_stats_generator_insert
  AFTER INSERT
  ON mobile_sms_entries
  FOR EACH ROW
  BEGIN
	IF NOT EXISTS(SELECT * FROM mobile_sms_stats WHERE date=DATE(NEW.scheduled_at) AND `user_id`=NEW.user_id)  THEN
        INSERT INTO `mobile_sms_stats`(`user_id`, `date`, `total_submitted`, `failed`, `total_sent`, `total_sent_count`) VALUES (NEW.user_id, DATE(NEW.scheduled_at), 0, 0, 0, 0);
    END IF;
    
    SELECT `id`, `total_submitted`  FROM mobile_sms_stats WHERE `date`=DATE(NEW.scheduled_at) AND  `user_id`=NEW.user_id INTO @id, @total_submitted;
    UPDATE mobile_sms_stats SET `total_submitted`= @total_submitted+1 WHERE `id`=@id ;
END;

